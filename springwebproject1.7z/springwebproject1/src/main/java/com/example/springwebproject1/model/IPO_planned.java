package com.example.springwebproject1.model;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="ipo_planned")
public class IPO_planned {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int ipo_id;
	
	//@Column(name="company_code")
	@Column
	private int companyCode;
	
	//@Column(name="stockexchange_id")
	@Column
	private int stockId;
	
	//@Column(name="price_per_share")
	@Column
	private BigDecimal price_per_share;
	
	//@Column(name="total_no_shares")
	@Column
	private int total_no_shares;
	
	//@Column(name="open_date_time")
	@Column
	private Date open_date_time;
	
	//@Column(name="remarks")
	@Column
	private String remarks;
	
	
	public IPO_planned() {
		// TODO Auto-generated constructor stub
	}
	
	
	


	public IPO_planned(int ipo_id, int companyCode, int stockId, BigDecimal price_per_share, int total_no_shares,
			Date open_date_time, String remarks) {
		super();
		this.ipo_id = ipo_id;
		this.companyCode = companyCode;
		this.stockId = stockId;
		this.price_per_share = price_per_share;
		this.total_no_shares = total_no_shares;
		this.open_date_time = open_date_time;
		this.remarks = remarks;
	}





	public int getIpo_id() {
		return ipo_id;
	}


	public void setIpo_id(int ipo_id) {
		this.ipo_id = ipo_id;
	}


	public int getCompanyCode() {
		return companyCode;
	}


	public void setCompanyCode(int companyCode) {
		this.companyCode = companyCode;
	}


	public int getStockId() {
		return stockId;
	}


	public void setStockId(int stockId) {
		this.stockId = stockId;
	}


	public BigDecimal getPrice_per_share() {
		return price_per_share;
	}


	public void setPrice_per_share(BigDecimal price_per_share) {
		this.price_per_share = price_per_share;
	}


	public int getTotal_no_shares() {
		return total_no_shares;
	}


	public void setTotal_no_shares(int total_no_shares) {
		this.total_no_shares = total_no_shares;
	}


	public Date getOpen_date_time() {
		return open_date_time;
	}


	public void setOpen_date_time(Date open_date_time) {
		this.open_date_time = open_date_time;
	}


	public String getRemarks() {
		return remarks;
	}


	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}





	@Override
	public String toString() {
		return "IPO_planned [ipo_id=" + ipo_id + ", companyCode=" + companyCode + ", stockId=" + stockId
				+ ", price_per_share=" + price_per_share + ", total_no_shares=" + total_no_shares + ", open_date_time="
				+ open_date_time + ", remarks=" + remarks + "]";
	}

    

	
	
	
}
