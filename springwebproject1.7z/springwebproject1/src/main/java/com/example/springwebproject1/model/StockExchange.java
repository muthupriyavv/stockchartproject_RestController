package com.example.springwebproject1.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="stockexchange")
public class StockExchange {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int stockexchangeId;
	
	@Column(name="stockexchange_name")
	private String stockexchange_name;
	
	@Column(name="brief")
	private String brief;
	
	@Column(name="contact_address")
	private String contact_address;
	
	@Column(name="remarks")
	private String remarks;
	
	
	public StockExchange() {
		
		// TODO Auto-generated constructor stub
	}
	
	
	public StockExchange(int stockexchange_id, String stockexchange_name, String brief, String contact_address,
			String remarks) {
		super();
		this.stockexchangeId = stockexchange_id;
		this.stockexchange_name = stockexchange_name;
		this.brief = brief;
		this.contact_address = contact_address;
		this.remarks = remarks;
	}


	public int getStockexchange_id() {
		return stockexchangeId;
	}
	public void setStockexchange_id(int stockexchange_id) {
		this.stockexchangeId = stockexchange_id;
	}
	public String getStockexchange_name() {
		return stockexchange_name;
	}
	public void setStockexchange_name(String stockexchange_name) {
		this.stockexchange_name = stockexchange_name;
	}
	public String getBrief() {
		return brief;
	}
	public void setBrief(String brief) {
		this.brief = brief;
	}
	public String getContact_address() {
		return contact_address;
	}
	public void setContact_address(String contact_address) {
		this.contact_address = contact_address;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	
}
